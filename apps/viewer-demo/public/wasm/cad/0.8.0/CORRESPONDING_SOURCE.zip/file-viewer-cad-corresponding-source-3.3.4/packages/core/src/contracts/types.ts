// Shared contracts for the whole core package.
//
// Keep this layer declarative: no DOM reads, renderer imports, or async loading
// should be introduced here. Higher layers depend on these contracts, never the
// other way around.
import type { FileViewerXmlOptions } from './xml'
import type { FileViewerResolvedLocale } from '../i18n/locales'
import type { FileViewerExtendedMessageKey } from '../i18n/domains'
import type { FileViewerSignatureOptions } from './signature'

export type FileViewerSourceKind = 'file' | 'url' | 'buffer' | 'empty'

export type FileViewerThemeMode = 'light' | 'dark' | 'system'

export type FileViewerResolvedThemeMode = Exclude<FileViewerThemeMode, 'system'>

export type FileViewerLocale = 'auto' | FileViewerResolvedLocale | (string & {})

export type FileViewerStyleIsolation = 'auto' | 'shadow' | 'scoped' | 'none'

export type FileViewerBaseMessageKey =
  | 'signature.panel.title'
  | 'signature.panel.show'
  | 'signature.panel.hide'
  | 'signature.panel.close'
  | 'signature.panel.reviewValidation'
  | 'signature.panel.validationNotices'
  | 'signature.panel.checksFailed'
  | 'signature.panel.checksIncomplete'
  | 'text.code.lineCount'
  | 'text.patch.summary'
  | 'text.xml.viewSource'
  | 'text.xml.viewRendered'
  | 'text.xml.diagnostics'
  | 'text.xml.renderedTitle'
  | 'media.midi.trackFallback'
  | 'media.midi.instrumentFallback'
  | 'toolbar.zoomGroup'
  | 'toolbar.zoomOut'
  | 'toolbar.zoomIn'
  | 'toolbar.zoomReset'
  | 'toolbar.download'
  | 'toolbar.downloadTitle'
  | 'toolbar.print'
  | 'toolbar.printTitle'
  | 'toolbar.printDirect'
  | 'toolbar.printMask'
  | 'toolbar.printMaskTitle'
  | 'toolbar.printMaskAdd'
  | 'toolbar.printMaskClear'
  | 'toolbar.printMaskCancel'
  | 'toolbar.printMaskConfirm'
  | 'toolbar.printMaskHint'
  | 'toolbar.printStampUpload'
  | 'toolbar.printStampRemove'
  | 'toolbar.printStampResize'
  | 'toolbar.exportHtml'
  | 'toolbar.exportHtmlTitle'
  | 'toolbar.search'
  | 'toolbar.searchPlaceholder'
  | 'toolbar.searchPrevious'
  | 'toolbar.searchNext'
  | 'toolbar.searchClear'
  | 'toolbar.searchClose'
  | 'toolbar.more'
  | 'toolbar.theme'
  | 'toolbar.themeToLight'
  | 'toolbar.themeToDark'
  | 'state.ready.title'
  | 'state.ready.message'
  | 'state.empty.title'
  | 'state.empty.message'
  | 'state.unsupported.install.title'
  | 'state.unsupported.install.message'
  | 'state.unsupported.install.description'
  | 'state.unsupported.title'
  | 'state.unsupported.message'
  | 'state.unsupported.description'
  | 'state.error.title'
  | 'preview.downloading'
  | 'preview.streamingPdf'
  | 'preview.reading'
  | 'error.download'
  | 'error.print'
  | 'error.exportHtml'
  | 'error.noDownloadSource'
  | 'error.noExportContent'
  | 'error.printUnavailable'
  | 'error.printWindowBlocked'
  | 'error.remoteDownload'
  | 'error.localRead'
  | 'error.load'
  | 'error.stream'
  | 'error.beforeOperation'
  | 'error.unknown'
  | 'error.blobUnavailable'
  | 'error.sourceUnsupported'
  | 'error.fileReadArrayBuffer'
  | 'error.fileReadDataUrl'
  | 'error.fileReadText'
  | 'error.imageDataUrlRead'
  | 'operation.download'
  | 'operation.print'
  | 'operation.exportHtml'
  | 'operation.zoomIn'
  | 'operation.zoomOut'
  | 'operation.zoomReset'
  | 'pdf.toolbar.toggleNavigation'
  | 'pdf.toolbar.previousPage'
  | 'pdf.toolbar.nextPage'
  | 'pdf.toolbar.fitWidth'
  | 'pdf.toolbar.zoomOut'
  | 'pdf.toolbar.zoomIn'
  | 'pdf.toolbar.rotateLeft'
  | 'pdf.toolbar.rotateRight'
  | 'pdf.nav.typeLabel'
  | 'pdf.nav.pagesTab'
  | 'pdf.nav.outlineTab'
  | 'pdf.nav.pagesTitle'
  | 'pdf.nav.outlineTitle'
  | 'pdf.nav.pageCount'
  | 'pdf.nav.itemCount'
  | 'pdf.nav.pageLabel'
  | 'pdf.nav.outlineEmpty'
  | 'pdf.nav.outlineFallbackTitle'
  | 'pdf.thumbnail.alt'
  | 'pdf.state.loading'
  | 'pdf.error.browserWindow'
  | 'pdf.error.missingSource'
  | 'pdf.error.loadFailed'
  | 'pdf.error.notLoaded'
  | 'pdf.error.unloaded'
  | 'pdf.error.canvasUnavailable'
  | 'pdf.export.pageTitle'
  | 'spreadsheet.loading.kicker'
  | 'spreadsheet.loading.title'
  | 'spreadsheet.loading.hint'
  | 'spreadsheet.loading.streaming'
  | 'spreadsheet.tabs.ariaLabel'
  | 'spreadsheet.state.parsingWorkbook'
  | 'spreadsheet.state.preparingSheet'
  | 'spreadsheet.state.preparingSheetNamed'
  | 'spreadsheet.state.cachedRows'
  | 'spreadsheet.state.rows'
  | 'spreadsheet.state.rowsAndColumns'
  | 'spreadsheet.error.parseFailed'
  | 'spreadsheet.error.workerFailed'
  | 'spreadsheet.comments.title'
  | 'spreadsheet.comments.close'
  | 'spreadsheet.comments.note'
  | 'spreadsheet.comments.thread'
  | 'spreadsheet.comments.resolved'
  | 'spreadsheet.comments.unknown'
  | 'spreadsheet.comments.empty'
  | 'spreadsheet.comments.more'
  | 'spreadsheet.comments.open'
  | 'spreadsheet.comments.jump'
  | 'spreadsheet.comments.warning'
  | 'spreadsheet.comments.count'
  | 'word.error.invalidDocx'
  | 'word.error.missingOdfContent'
  | 'word.error.odfXmlParseFailed'
  | 'word.title.rtf'
  | 'word.title.openDocumentPresentation'
  | 'word.title.openDocumentText'
  | 'word.page.fallback'
  | 'word.page.empty'
  | 'word.body'
  | 'word.body.empty'
  | 'ofd.toolbar.pageNavigation'
  | 'ofd.toolbar.documentPages'
  | 'ofd.toolbar.previousPage'
  | 'ofd.toolbar.nextPage'
  | 'ofd.toolbar.pageStatus'
  | 'ofd.toolbar.noPages'
  | 'ofd.state.loading'
  | 'ofd.error.empty'
  | 'ofd.error.parseFailed'
  | 'presentation.state.loading'
  | 'presentation.error.title'
  | 'presentation.error.parseFailed'
  | 'presentation.ppt.state.loading'
  | 'presentation.ppt.error.title'
  | 'presentation.ppt.error.parseFailed'
  | 'presentation.ppt.error.assetHint'
  | 'presentation.slideshow.start'
  | 'presentation.slideshow.exit'
  | 'presentation.slideshow.hint'
  | 'archive.error.nestedUnsupported'
  | 'archive.loading.readingDirectory'
  | 'archive.loading.readingDirectoryHint'
  | 'archive.search.placeholder'
  | 'archive.sidebar.hide'
  | 'archive.sidebar.show'
  | 'archive.preview.title'
  | 'archive.preview.chooseFile'
  | 'archive.preview.downloadFile'
  | 'archive.error.title'
  | 'archive.stats.summary'
  | 'archive.warning.encrypted'
  | 'archive.password.title'
  | 'archive.password.description'
  | 'archive.password.placeholder'
  | 'archive.password.invalid'
  | 'archive.password.required'
  | 'archive.password.cancel'
  | 'archive.password.confirm'
  | 'archive.error.passwordRequired'
  | 'archive.error.encryptedRequiresWorker'
  | 'archive.empty.title'
  | 'archive.empty.message'
  | 'archive.loading.initializingCandidate'
  | 'archive.loading.initializingCandidateHint'
  | 'archive.error.candidateInitTimeout'
  | 'archive.error.encryptedCheckTimeout'
  | 'archive.loading.directoryReadyHint'
  | 'archive.error.candidateReadTimeout'
  | 'archive.loading.workerFallback'
  | 'archive.loading.workerFallbackHint'
  | 'archive.notice.workerFallback'
  | 'archive.error.tooLarge'
  | 'archive.loading.initializingWorker'
  | 'archive.loading.initializingWorkerHint'
  | 'archive.error.workerInitFailed'
  | 'archive.error.workerUnsupported'
  | 'archive.error.indexedDbUnavailable'
  | 'archive.error.entryTooLarge'
  | 'archive.loading.extracting'
  | 'archive.loading.rendering'
  | 'archive.loading.exporting'
  | 'media.audio.title'
  | 'media.audio.description'
  | 'media.audio.unsupported'
  | 'media.video.title'
  | 'media.video.unsupported'
  | 'media.video.hlsHint'
  | 'media.video.codecUnsupportedBadge'
  | 'media.video.codecUnsupportedTitle'
  | 'media.video.codecUnsupportedDescription'
  | 'media.video.codecUnsupportedAction'
  | 'media.video.softwareWorkerFailed'
  | 'media.video.softwareLoading'
  | 'media.video.softwareBadge'
  | 'media.video.play'
  | 'media.video.pause'
  | 'media.video.seek'
  | 'media.video.mute'
  | 'media.video.unmute'
  | 'media.video.fullscreen'
  | 'media.midi.title'
  | 'media.midi.loading'
  | 'media.midi.trackHeader'
  | 'media.midi.instrumentHeader'
  | 'media.midi.channelHeader'
  | 'media.midi.noteCountHeader'
  | 'media.midi.durationHeader'
  | 'media.midi.durationStat'
  | 'media.midi.trackStat'
  | 'media.midi.noteStat'
  | 'media.midi.parseFailed'
  | 'email.mbox.subject'
  | 'email.mbox.summary'
  | 'email.error.title'
  | 'email.meta.from'
  | 'email.meta.to'
  | 'email.meta.cc'
  | 'email.meta.date'
  | 'email.tabs.text'
  | 'email.tabs.headers'
  | 'email.attachments.title'
  | 'email.attachments.empty'
  | 'email.attachments.download'
  | 'email.attachments.opening'
  | 'email.attachments.nestedUnavailable'
  | 'email.loading.parsing'
  | 'data.font.sample'
  | 'data.error.fontFaceUnsupported'
  | 'data.title.font'
  | 'data.title.sqlite'
  | 'data.title.parquet'
  | 'data.title.avro'
  | 'data.title.wasm'
  | 'data.title.eps'
  | 'data.title.ai'
  | 'data.title.webarchive'
  | 'data.title.summary'
  | 'data.label.format'
  | 'data.label.size'
  | 'data.label.rendering'
  | 'data.label.objects'
  | 'data.label.sampleTable'
  | 'data.label.rows'
  | 'data.label.columns'
  | 'data.label.sampleRows'
  | 'data.label.imports'
  | 'data.label.exports'
  | 'data.label.magic'
  | 'data.label.note'
  | 'data.label.container'
  | 'data.value.schemaRead'
  | 'data.value.schemaUnread'
  | 'data.note.aiSummary'
  | 'data.note.postscriptSummary'
  | 'data.note.webarchive'
  | 'data.image.alt'
  | 'psd.title'
  | 'psd.action.fit'
  | 'psd.action.showAll'
  | 'psd.action.hideAll'
  | 'psd.layers.title'
  | 'psd.layers.redrawable'
  | 'psd.layers.empty'
  | 'psd.layers.hidden'
  | 'drawing.error.viewerLoadFailed'
  | 'drawing.error.excalidrawEmpty'
  | 'drawing.error.excalidrawTimeout'
  | 'drawing.error.drawioParseFailed'
  | 'drawing.error.drawioNoModel'
  | 'drawing.error.drawioNoElements'
  | 'drawing.error.viewerInitFailed'
  | 'drawing.error.drawioTimeout'
  | 'drawing.error.svgParseFailed'
  | 'drawing.error.plantumlRenderFailed'
  | 'drawing.title.excalidraw'
  | 'drawing.title.mermaid'
  | 'drawing.title.plantuml'
  | 'drawing.title.drawio'
  | 'drawing.toolbar.zoomOut'
  | 'drawing.toolbar.zoomIn'
  | 'drawing.toolbar.fit'
  | 'drawing.toolbar.fitWidth'
  | 'drawing.state.loading'
  | 'text.code.loadingHighlight'
  | 'text.code.formattedPreview'
  | 'text.code.showOriginal'
  | 'text.html.preview'
  | 'text.html.source'
  | 'text.html.safePreview'
  | 'text.code.showFormatted'
  | 'text.code.indexingLargeFile'
  | 'text.code.virtualized'
  | 'text.code.firstSegment'
  | 'text.code.previousSegment'
  | 'text.code.nextSegment'
  | 'text.code.lastSegment'
  | 'ebook.toc'
  | 'ebook.reading'
  | 'ebook.itemCount'
  | 'epub.title'
  | 'epub.previousPage'
  | 'epub.nextPage'
  | 'epub.loading'
  | 'epub.chapterFallback'
  | 'epub.renderIncomplete'
  | 'umd.title'
  | 'umd.previousChapter'
  | 'umd.nextChapter'
  | 'umd.loading'
  | 'umd.emptyContent'
  | 'umd.chapterFallback'
  | 'umd.galleryFallback'
  | 'umd.warningBodyTooShort'
  | 'umd.error.unexpectedEnd'
  | 'umd.error.invalidFile'
  | 'typst.summaryRenderer'
  | 'typst.pageSummary.empty'
  | 'typst.pageSummary.ready'
  | 'typst.status.compiling'
  | 'typst.status.failed'
  | 'typst.status.rendered'
  | 'typst.loading.title'
  | 'typst.loading.hint'
  | 'typst.error.title'
  | 'typst.error.timeout'
  | 'typst.error.timeoutHint'
  | 'typst.error.assetHint'
  | 'typst.error.svgParseFailed'
  | 'typst.error.wasmLoadFailed'
  | 'xmind.toolbar.zoomOut'
  | 'xmind.toolbar.zoomIn'
  | 'xmind.toolbar.fit'
  | 'xmind.toolbar.fitTitle'
  | 'xmind.state.loading'
  | 'xmind.stats.nodes'
  | 'xmind.stats.depth'
  | 'xmind.stats.theme'
  | 'xmind.stats.template'
  | 'xmind.badge.paused'
  | 'xmind.badge.collapsed'
  | 'xmind.badge.floating'
  | 'xmind.badge.summary'
  | 'xmind.badge.callout'
  | 'xmind.imageResource'
  | 'xmind.error.unrecognized'
  | 'xmind.error.noCanvas'
  | 'cad.toolbar.fit'
  | 'cad.toolbar.zoomOut'
  | 'cad.toolbar.zoomIn'
  | 'cad.toolbar.colorSource'
  | 'cad.toolbar.monochrome'
  | 'cad.toolbar.exportImage'
  | 'cad.layers.title'
  | 'cad.layers.count'
  | 'cad.layers.merged'
  | 'cad.inspector.title'
  | 'cad.inspector.entities'
  | 'cad.inspector.blocks'
  | 'cad.inspector.pages'
  | 'cad.inspector.drawn'
  | 'cad.state.loadingViewer'
  | 'cad.state.parsing'
  | 'cad.error.parseFailed'
  | 'cad.error.exportFailed'
  | 'image.alt'
  | 'image.toolbar.rotation'
  | 'image.toolbar.rotateLeft'
  | 'image.toolbar.rotateRight'
  | 'image.lightbox.alt'
  | 'image.lightbox.close'
  | 'gitBundle.error.invalid'
  | 'gitBundle.error.missingPack'
  | 'gitBundle.notice.delta'
  | 'gitBundle.title.history'
  | 'gitBundle.title.fileTree'
  | 'gitBundle.file.choose'
  | 'gitBundle.file.noTree'
  | 'gitBundle.file.none'
  | 'gitBundle.history.empty'
  | 'gitBundle.toolbar.summary'
  | 'gitBundle.meta.bundle'
  | 'gitBundle.meta.refs'
  | 'gitBundle.meta.commits'
  | 'gitBundle.meta.objects'
  | 'gitBundle.meta.deltas'
  | 'gitBundle.meta.objectFormat'
  | 'gitBundle.meta.objectTypes'
  | 'geo.error.unrecognized'
  | 'geo.error.xmlParseFailed'
  | 'geo.error.unsupported'
  | 'geo.title'
  | 'geo.featureCount'
  | 'geo.bounds'
  | 'geo.geometryTypes'
  | 'geo.aria'
  | 'geo.loading'
  | 'geo.projection'
  | 'geo.engine'
  | 'geo.basemap'
  | 'geo.basemap.offline'
  | 'geo.basemap.custom'
  | 'geo.engine.maplibre'
  | 'geo.engine.svg'
  | 'geo.error.projection'
  | 'geo.action.fit'
  | 'model.toolbar.fit'
  | 'model.toolbar.rotate'
  | 'model.toolbar.wireframe'
  | 'model.toolbar.grid'
  | 'model.toolbar.axes'
  | 'model.state.loadingSummary'
  | 'model.state.loading'
  | 'model.state.loaded'
  | 'model.state.parseFailed'
  | 'model.summary.meshes'
  | 'model.summary.points'
  | 'model.error.daeEmpty'
  | 'model.error.unsupported'
  | 'model.error.parseFailed'
  | 'model.notice.signature'
  | 'loading.generic.label'
  | 'loading.generic.hint'
  | 'loading.word.label'
  | 'loading.word.hint'
  | 'loading.wordWorker.hint'
  | 'loading.sheet.label'
  | 'loading.sheet.hint'
  | 'loading.csv.label'
  | 'loading.csv.hint'
  | 'loading.presentation.label'
  | 'loading.presentation.hint'
  | 'loading.pdf.label'
  | 'loading.pdf.hint'
  | 'loading.ofd.label'
  | 'loading.ofd.hint'
  | 'loading.archive.label'
  | 'loading.archive.hint'
  | 'loading.email.label'
  | 'loading.email.hint'
  | 'loading.msg.hint'
  | 'loading.eda.label'
  | 'loading.eda.hint'
  | 'loading.cad.label'
  | 'loading.cad.hint'
  | 'loading.dwg.hint'
  | 'loading.dwf.hint'
  | 'loading.dwfx.hint'
  | 'loading.xps.hint'
  | 'loading.drawio.label'
  | 'loading.drawio.hint'
  | 'loading.excalidraw.label'
  | 'loading.excalidraw.hint'
  | 'loading.epub.label'
  | 'loading.epub.hint'
  | 'loading.umd.label'
  | 'loading.umd.hint'
  | 'loading.image.label'
  | 'loading.image.hint'
  | 'loading.video.label'
  | 'loading.video.hint'
  | 'loading.audio.label'
  | 'loading.audio.hint'

export type FileViewerMessageKey = FileViewerBaseMessageKey | FileViewerExtendedMessageKey

export type FileViewerMessageParams = Record<string, string | number | boolean | null | undefined>

export type FileViewerMessageResolver = (
  key: FileViewerMessageKey,
  params: FileViewerMessageParams,
  locale: FileViewerLocale
) => string | undefined

export type FileViewerMessages =
  Partial<Record<FileViewerMessageKey, string>> | FileViewerMessageResolver

export interface FileViewerI18nOptions {
  locale?: FileViewerLocale
  messages?: FileViewerMessages
}

/** Per-viewer language state. Subscribers must unsubscribe when their UI is disposed. */
export interface FileViewerI18nContext {
  readonly locale: FileViewerResolvedLocale
  readonly options: FileViewerOptions
  t(key: FileViewerMessageKey, params?: FileViewerMessageParams): string
  formatNumber(value: number, options?: Intl.NumberFormatOptions): string
  formatDateTime(value: Date | number, options?: Intl.DateTimeFormatOptions): string
  formatBytes(value: number): string
  subscribe(listener: () => void): () => void
}

export type FileViewerFileRef = File | Blob | ArrayBuffer

export type FileViewerToolbarPosition = 'auto' | 'top' | 'top-center' | 'bottom-right'

export type FileViewerFitMode =
  'auto' | 'contain' | 'cover' | 'width' | 'height' | 'actual' | 'scale-down'

export type FileViewerFitResize = 'until-interaction' | 'always' | 'initial'

export interface FileViewerFitOptions {
  mode?: FileViewerFitMode
  resize?: FileViewerFitResize
  padding?: number
  minScale?: number
  maxScale?: number
}

export type FileViewerLifecyclePhase =
  'load-start' | 'load-complete' | 'unload-start' | 'unload-complete'

export type FileViewerOperationType =
  'download' | 'print' | 'export-html' | 'zoom-in' | 'zoom-out' | 'zoom-reset'

export type FileViewerToolbarItem =
  'search' | 'zoom' | 'download' | 'print' | 'exportHtml' | 'export-html' | 'theme'

export type FileViewerResolvedToolbarItem =
  'search' | 'zoom' | 'download' | 'print' | 'exportHtml' | 'theme'

export type FileViewerToolbarActionMap = Partial<Record<FileViewerOperationType, boolean>>

export type FileViewerRenderStateKind =
  'idle' | 'loading' | 'ready' | 'empty' | 'unsupported' | 'error'

export type FileViewerRendererCategory =
  | 'office'
  | 'document'
  | 'archive'
  | 'email'
  | 'eda'
  | 'cad'
  | 'model'
  | 'geo'
  | 'drawing'
  | 'mindmap'
  | 'ebook'
  | 'image'
  | 'medical-image'
  | 'cryptographic-container'
  | 'markdown'
  | 'code'
  | 'media'
  | 'asset'
  | 'fallback'

export interface FileViewerWatermarkOptions {
  enabled?: boolean
  text?: string
  image?: string
  opacity?: number
  rotate?: number
  gapX?: number
  gapY?: number
  width?: number
  height?: number
  fontSize?: number
  color?: string
  fontFamily?: string
}

export interface FileViewerToolbarOptions {
  download?: boolean
  print?: boolean
  exportHtml?: boolean
  zoom?: boolean
  search?: boolean
  /** Shows a manual light/dark mode toggle without changing the host page theme. */
  theme?: boolean
  /** Built-in toolbar group order. Missing entries keep their default relative order. */
  order?: FileViewerToolbarItem[]
  /** Controls which built-in toolbar actions are displayed without disabling controller APIs. */
  items?: FileViewerToolbarActionMap
  /** Hard operation permission map. False values block both built-in toolbar and public API calls. */
  permissions?: FileViewerToolbarActionMap
  position?: FileViewerToolbarPosition
  beforeOperation?: FileViewerBeforeOperation
  beforeDownload?: FileViewerBeforeOperation
  beforePrint?: FileViewerBeforeOperation
  beforeExportHtml?: FileViewerBeforeOperation
}

export interface FileViewerArchiveEntryActionContext {
  path: string
  name: string
  extension: string
  size: number
  lastModified?: number
  depth: number
  previewable: boolean
}

export type FileViewerArchiveEntryActionPolicy =
  boolean | ((entry: FileViewerArchiveEntryActionContext) => boolean)

export interface FileViewerArchiveEntryActionsOptions {
  /**
   * Controls the download button for files opened from inside an archive.
   * The viewer-level original-file download remains controlled by toolbar options.
   */
  download?: FileViewerArchiveEntryActionPolicy
}

export interface FileViewerArchiveOptions {
  workerUrl?: string
  wasmUrl?: string
  workerTimeoutMs?: number
  cache?: boolean
  /**
   * Maximum input bytes, and maximum expanded TAR/GZIP bytes in the workerless
   * fallback (including TAR headers and padding). Defaults to 320 MiB.
   * Must be a non-negative safe integer; zero permits only empty data.
   */
  maxArchiveSize?: number
  /**
   * Maximum selected entry preview bytes. Defaults to 64 MiB. Also bounds
   * single-file GZIP expansion during fallback listing; TAR/TGZ members are
   * checked when selected. Must be a non-negative safe integer.
   */
  maxEntryPreviewSize?: number
  entryActions?: FileViewerArchiveEntryActionsOptions
  /**
   * Optional archive password. It is used for the first encrypted archive
   * attempt; if it is wrong, the built-in password dialog or requestPassword
   * callback can still ask the user for a replacement.
   */
  password?: string
  /**
   * Custom password request hook for encrypted archives. Return a string to
   * continue, or null/undefined to cancel and surface a friendly error.
   */
  requestPassword?: (
    context: FileViewerArchivePasswordRequestContext
  ) => string | null | undefined | Promise<string | null | undefined>
}

export interface FileViewerChmOptions {
  /** Self-hosted module Worker that owns all untrusted CHM parsing and decompression. */
  workerUrl?: string | URL
  /** Self-hosted wasm-bindgen JavaScript module loaded by the CHM Worker. */
  wasmModuleUrl?: string | URL
  /** Self-hosted Rust WebAssembly binary loaded by the CHM Worker. */
  wasmUrl?: string | URL
  /** Maximum time for an individual Worker request. Defaults to 60 seconds. */
  workerTimeoutMs?: number
  /** Maximum accepted CHM input size. Defaults to 320 MiB. */
  maxArchiveBytes?: number
  /** Maximum number of virtual files accepted from one CHM. Defaults to 50,000. */
  maxEntries?: number
  /** Maximum uncompressed size of one virtual file. Defaults to 32 MiB. */
  maxEntryBytes?: number
  /** Maximum total unique decoded content exposed by the parser. Defaults to 512 MiB. */
  maxTotalDecompressedBytes?: number
  /** Maximum HTML topic size. Defaults to 16 MiB. */
  maxHtmlBytes?: number
  /** Maximum topic count scanned by the built-in search. Defaults to 10,000. */
  maxSearchTopics?: number
  /** Maximum built-in search result count. Defaults to 200. */
  maxSearchResults?: number
}

export type FileViewerArchivePasswordRequestReason =
  'encrypted' | 'invalid-password' | 'read-failed' | 'extract-failed'

export interface FileViewerArchivePasswordRequestContext {
  filename: string
  entryName?: string
  attempt: number
  reason: FileViewerArchivePasswordRequestReason
  error?: unknown
}

export interface FileViewerPdfOptions {
  /** Preview-only dark reading palette; follows the viewer theme when omitted. */
  darkMode?: boolean
  /** Opt-in mouse hand-tool panning. Touch/pinch, links and form fields remain native. Default: false. */
  handTool?: boolean
  toolbar?: boolean
  /** Hides only the PDF renderer's zoom controls; navigation and rotation remain available. Default: true. */
  zoomToolbar?: boolean
  navigation?: boolean
  defaultNavigationVisible?: boolean
  thumbnails?: boolean
  rotation?: number
  /**
   * Highlights and focuses one or more PDF regions after the document loads.
   * Use `pixel` with `sourceWidth` / `sourceHeight` for OCR coordinates, or
   * `pdf-point` for native PDF coordinates. Page numbers are one-based.
   */
  bbox?: FileViewerPdfBoundingBox | readonly FileViewerPdfBoundingBox[]
  /**
   * Initial PDF view position. Prefer the top-level `initialViewState` when the
   * same state should be passed through framework-neutral viewer APIs.
   */
  initialViewState?: FileViewerViewState
  streaming?: boolean | 'same-origin'
  /** Opt out of PDF.js background streaming while retaining HTTP Range reads. Default: PDF.js defaults. */
  disableStream?: boolean
  /** Stop speculative PDF.js reads; requires disableStream:true to be fully effective. */
  disableAutoFetch?: boolean
  rangeChunkSize?: number
  withCredentials?: boolean
  /**
   * Base URL for the self-hosted PDF worker, cMaps, WASM, standard fonts, and
   * CJK fallback fonts. Useful for SPA routes whose document URL is deeper
   * than the deployment public path, for example `/workspace/c/`.
   */
  assetBaseUrl?: string | URL
  workerUrl?: string
  cMapUrl?: string
  wasmUrl?: string
  standardFontDataUrl?: string
  /**
   * Enables the self-hosted CJK fallback used when a PDF references a font
   * such as Microsoft YaHei without embedding the font data. Defaults to true.
   */
  cjkFontFallback?: boolean
  /**
   * Repairs malformed Identity-H/V CJK fonts that omit ToUnicode when the PDF
   * also embeds a usable same-family TrueType cmap. Defaults to true. The
   * repair is applied only to the in-memory preview and never changes the
   * original file used by download operations.
   */
  identityFontRepair?: boolean
  /**
   * Directory containing `noto-sans-sc.css`, its `files/` font shards, and
   * the bundled font license. The path is resolved against the document base.
   */
  cjkFontFallbackPath?: string
}

export type FileViewerPdfBoundingBoxUnit = 'ratio' | 'percent' | 'pixel' | 'pdf-point'

export type FileViewerPdfBoundingBoxOrigin = 'top-left' | 'bottom-left'

export interface FileViewerPdfBoundingBox {
  id?: string
  /** One-based PDF page number. Defaults to the current page, then page 1. */
  page?: number
  x: number
  y: number
  width: number
  height: number
  /** Defaults to `pdf-point`. */
  unit?: FileViewerPdfBoundingBoxUnit
  /** Defaults to `bottom-left` for PDF points and `top-left` otherwise. */
  origin?: FileViewerPdfBoundingBoxOrigin
  /** Required when `unit` is `pixel`; this is the OCR/source image width. */
  sourceWidth?: number
  /** Required when `unit` is `pixel`; this is the OCR/source image height. */
  sourceHeight?: number
  /** CSS color used for the outline and translucent fill. */
  color?: string
  /** Optional accessible description for the highlighted region. */
  label?: string
}

export interface FileViewerDocxOptions {
  /**
   * 输出源部件与段落的只读定位标识，供独立展示适配器使用；默认关闭。
   * 不提供编辑或文件写回能力，重新渲染后的展示状态由适配器维护。
   */
  exposeDisplayTargets?: boolean
  /** DOC/DOCX 默认保留插入和删除修订；final 显示定稿，original 显示修订前原稿。 */
  reviewMode?: 'all' | 'final' | 'original'
  worker?: boolean
  workerUrl?: string
  workerJsZipUrl?: string
  progressive?: boolean
  /** 默认 false，使用连续流式阅读；设为 true 时才启用 DOCX 页式预览。 */
  visualPagination?: boolean
  workerTimeout?: number
  renderPageBatchSize?: number
  renderYieldEveryMs?: number
  strictWordCompatibility?: boolean
  paginationTolerance?: number
  maxDynamicPaginationPasses?: number
  awaitLayout?: boolean
  preserveComplexFieldResults?: boolean
  updatePageReferences?: boolean
  hideWebHiddenContent?: boolean
  ignoreLastRenderedPageBreak?: boolean
  /** Set false to omit embedded HTML altChunks. Omitted/true retains the engine sandbox. */
  renderAltChunks?: boolean
  /** External DOC/DOCX/RTF links are blocked by default; internal bookmark links remain active. */
  externalLinkPolicy?: 'allow' | 'block'
  /** Linked DOC/DOCX/RTF image resources are blocked by default; embedded images remain available. */
  externalResourcePolicy?: 'allow' | 'block'
  /** Overrides automatic DOCX dark rendering derived from the viewer theme. */
  darkMode?: boolean
}

export interface FileViewerEpubOptions {
  /** Follows the viewer theme when omitted; false retains the book's authored colors. */
  darkMode?: boolean
}

export interface FileViewerSpreadsheetOptions {
  worker?: boolean | 'auto'
  workerUrl?: string
  /** `worker: 'auto'` 时，大于该字节数的表格自动使用静态 Worker，默认 1MB。 */
  workerAutoThreshold?: number
  /**
   * CSV / TSV 文本编码。默认 `auto`：优先 UTF-8 BOM 和严格 UTF-8，
   * 否则使用浏览器内置 GB18030 解码器（同时覆盖 GBK）。
   */
  textEncoding?: 'auto' | 'utf-8' | 'gbk' | 'gb18030'
  /** 允许用户在 Excel / CSV / ODS 预览中拖拽表头边界调整列宽，默认关闭以保持历史行为。 */
  resizableColumns?: boolean
  /** 允许用户在 Excel / CSV / ODS 预览中拖拽行头边界调整行高，默认关闭以保持历史行为。 */
  resizableRows?: boolean
  /**
   * Defaults to `source`: gutter numbers match source rows and A1 search addresses.
   * `legacy-records` restores the historical header heuristic and marks the gutter
   * with `#`. These are record ordinals, not cell addresses; header-like first
   * rows are unnumbered. Search, data and zero-based ranges keep source coordinates.
   */
  rowNumberMode?: 'source' | 'legacy-records'
  /** Fill spreadsheet previews with display-only blank grid cells by default; false keeps the used range only. */
  fillViewport?: boolean
}

export interface FileViewerPresentationOptions {
  /** PPTX/OpenXML Worker URL. This is independent from the binary-PPT Worker. */
  workerUrl?: string | URL
  workerType?: WorkerType
  /** @deprecated Accepted for migration; the TypeScript PPT engine does not load WASM. */
  pptWasmUrl?: string | URL
  /** @deprecated Accepted for migration; PPT uses fonts provided by the host browser. */
  pptFontUrl?: string | URL
  /** Optional module Worker URL used only by the PowerPoint 97–2003 renderer. */
  pptWorkerUrl?: string | URL
  /** Selects the binary-PPT Worker path. Defaults to `auto`. */
  pptWorker?: boolean | 'auto'
  /** @deprecated Accepted for migration; the TypeScript PPT engine has no persistent frame cache. */
  pptCache?:
    | false
    | {
        enabled?: boolean
        dbName?: string
        maxBytes?: number
        maxEntries?: number
        maxEntryBytes?: number
      }
  /** Render and retain only binary-PPT slides near the viewport. Defaults to true. */
  pptVirtualize?: boolean
  /** IntersectionObserver overscan for binary-PPT virtualization. Defaults to `150% 0px`. */
  pptVirtualRootMargin?: string
  /** Delay before an offscreen binary-PPT canvas is cached and released. Defaults to 1200ms. */
  pptReleaseDelayMs?: number
  /**
   * Optional ESM entry override for `@file-viewer/ppt`.
   * Full packages and the CDN/IIFE distribution provide a packaged default.
   */
  pptModuleUrl?: string | URL
}

export type FileViewerIworkEmbeddedPreviewMode = 'never' | 'loading' | 'fallback'

export interface FileViewerIworkOptions {
  /** Self-hosted module Worker used for ZIP, Snappy, IWA/Protobuf and iWork '09 XML parsing. */
  workerUrl?: string | URL
  /** Defaults to true. Disable only in environments without Worker support. */
  useWorker?: boolean
  /** Maximum parse time before the Worker is terminated. Defaults to 60 seconds. */
  workerTimeoutMs?: number
  /** Maximum total bytes produced while inflating the outer container and Index.zip. Defaults to 256 MiB. */
  maxUncompressedBytes?: number
  /** Maximum accepted ZIP compression ratio for a single entry. Defaults to 200. */
  maxCompressionRatio?: number
  /** Maximum decoded IWA archive/object count. Defaults to 250,000. */
  maxObjects?: number
  /** Maximum decoded image pixels for one media resource. Defaults to 80 megapixels. */
  maxImagePixels?: number
  /** Maximum normalized scene/object nesting depth. Defaults to 128. */
  maxNestingDepth?: number
  /** Embedded Quick Look images are loading placeholders or explicit parse-failure fallbacks, never fidelity evidence. */
  embeddedPreview?: FileViewerIworkEmbeddedPreviewMode
}

export interface FileViewerWordPerfectOptions {
  /** Self-hosted Worker that owns WordPerfect signature detection and parsing. */
  workerUrl?: string | URL
  /** Self-hosted libwpd/librevenge WebAssembly module. */
  wasmUrl?: string | URL
  /** Defaults to true. */
  useWorker?: boolean
  /** Maximum parser time before the Worker is terminated. Defaults to 60 seconds. */
  workerTimeoutMs?: number
}

export interface FileViewerHangulOptions {
  /** Self-hosted module Worker used for bounded HWP v5 CFB and HWPX ZIP/XML parsing. */
  workerUrl?: string | URL
  /** Defaults to true. Disable only in environments without Worker support. */
  useWorker?: boolean
  /** Maximum parser time before the Worker is terminated. Defaults to 60 seconds. */
  workerTimeoutMs?: number
  /** Maximum total uncompressed HWPX entry bytes or individual HWP stream bytes. Defaults to 256 MiB. */
  maxUncompressedBytes?: number
  /** Maximum accepted HWPX ZIP compression ratio for a single entry. Defaults to 200. */
  maxCompressionRatio?: number
  /** Maximum HWPX ZIP entry count. Defaults to 25,000. */
  maxEntries?: number
  /** Maximum HWP record count decoded across one stream. Defaults to 250,000. */
  maxRecords?: number
}

export type FileRenderExportMode = 'export' | 'print'

export type FileViewerRenderPurpose = 'preview' | 'thumbnail'

export type FileViewerThumbnailFormat = 'webp' | 'jpeg' | 'png'

export type FileViewerThumbnailFit = 'contain' | 'cover'

export interface FileViewerThumbnailCaptureOptions {
  width: number
  height: number
  format: FileViewerThumbnailFormat
  quality: number
  fit: FileViewerThumbnailFit
  background: string
  signal?: AbortSignal
}

export interface FileRenderThumbnailAdapter {
  /** Prepare lazy content immediately before capture. */
  beforeCapture?: (options: FileViewerThumbnailCaptureOptions) => void | Promise<void>
  /** Identifies a capture result that comes from packaged metadata rather than rendered content. */
  captureSource?: 'embedded' | 'rendered'
  /** A renderer-native fast path. Returning null delegates to the DOM fallback. */
  capture?: (options: FileViewerThumbnailCaptureOptions) => Blob | null | Promise<Blob | null>
  /** The first page/slide/sheet/cover element used by the DOM fallback. */
  getTarget?: (
    options: FileViewerThumbnailCaptureOptions
  ) => Element | null | Promise<Element | null>
}

export interface FileRenderExportOptions {
  mode: FileRenderExportMode
  title: string
}

export interface FileRenderExportAdapter {
  print?: boolean
  exportHtml?: boolean
  includeDocumentStyles?: boolean
  beforeSnapshot?: () => Promise<void> | void
  /** Live page surfaces used by the interactive print-mask designer. */
  getPrintMaskPages?: () => readonly HTMLElement[]
  printStyle?: string | ((options: FileRenderExportOptions) => Promise<string> | string)
  toHtml?: (options: FileRenderExportOptions) => Promise<string> | string
}

export interface FileRenderContext {
  filename?: string
  url?: string
  streamUrl?: string
  /** Original browser File or Blob retained for renderers with random access. */
  sourceFile?: File | Blob
  signal?: AbortSignal
  options?: FileViewerOptions
  /** Live UI language inherited by attachments; document content is never translated. */
  i18n?: FileViewerI18nContext
  surface?: RenderSurface
  registerExportAdapter?: (adapter: FileRenderExportAdapter | null) => void
  registerThumbnailAdapter?: (adapter: FileRenderThumbnailAdapter | null) => void
  renderPurpose?: FileViewerRenderPurpose
  /** Derived-image download, guarded by the owning viewer's permissions, hooks and request version. */
  requestSnapshotDownload?: (
    create: (watermark: FileViewerOptions['watermark']) => Promise<{ blob: Blob; filename: string }>
  ) => Promise<boolean>
  onProgressiveRender?: () => void
  renderNestedBuffer?: (
    buffer: ArrayBuffer,
    type: string,
    target: HTMLDivElement,
    context?: FileRenderContext
  ) => Promise<FileViewerRenderedInstance | undefined>
}

export type FileRenderHandler<Rendered = unknown, Target extends HTMLElement = HTMLElement> = (
  buffer: ArrayBuffer,
  target: Target,
  type?: string,
  context?: FileRenderContext
) => Promise<Rendered>

export interface FileRenderHandlerComposite<
  Rendered = unknown,
  Target extends HTMLElement = HTMLElement
> {
  accepts: Array<string>
  handler: FileRenderHandler<Rendered, Target>
}

/**
 * Framework-neutral instance returned by a renderer after it mounts content.
 *
 * Vue, React legacy, Web Components or imperative renderers may expose different
 * teardown names, but wrappers can share this single contract when bridging old
 * renderer handlers into the core registry.
 */
export type FileViewerRenderedInstance =
  | {
      $el?: Node
      unmount: () => void | Promise<void>
    }
  | {
      $el?: Node
      $destroy: () => void | Promise<void>
    }
  | {
      $el?: Node
      destroy: () => void | Promise<void>
    }

export interface FileViewerTypstOptions {
  compilerWasmUrl?: string
  rendererWasmUrl?: string
  fontAssetsUrl?: string
  renderTimeoutMs?: number
}

export type FileViewerModelLinearUnit = 'millimeter' | 'centimeter' | 'meter' | 'inch' | 'foot'

export interface FileViewerModelOptions {
  /** Self-hosted worker that keeps STEP/IGES/BREP tessellation off the UI thread. */
  workerUrl?: string
  /** Self-hosted occt-import-js runtime loaded by the classic worker. */
  runtimeUrl?: string
  /** Self-hosted OpenCascade WebAssembly module used by the model renderer. */
  wasmUrl?: string
  /** Disable only when Worker is unavailable or a host deliberately accepts main-thread parsing. */
  useWorker?: boolean
  /** Maximum time allowed for geometry-kernel initialization and tessellation. Defaults to 120 seconds. */
  workerTimeoutMs?: number
  linearUnit?: FileViewerModelLinearUnit
  linearDeflectionType?: 'bounding_box_ratio' | 'absolute_value'
  linearDeflection?: number
  angularDeflection?: number
}

export interface FileViewerDataOptions {
  sqlWasmUrl?: string
}

/** Limits for the explicit, read-only binary inspector renderer. */
export interface FileViewerBinaryInspectorOptions {
  /** Whole-input ceiling before the renderer copies bytes into its Worker. Defaults to 16 MiB. */
  maxFileBytes?: number
  /** Maximum time allowed for one structure-template pass. Defaults to 5 seconds. */
  maxParseMilliseconds?: number
  /** Maximum structure nodes returned from the Worker. Defaults to 512. */
  maxStructureNodes?: number
  /** Maximum structure-tree nesting depth. Defaults to 16. */
  maxStructureDepth?: number
  /** Maximum decoded string bytes in one displayed field. Defaults to 4 KiB. */
  maxStringBytes?: number
}

export type FileViewerIllustratorMode = 'auto' | 'pdf' | 'native'

/** Resource budgets forwarded to the standalone illustrator-pgf Worker. */
export interface FileViewerIllustratorLimits {
  maxFileBytes: number
  maxDecodedBytes: number
  maxPdfObjects: number
  maxPrivateBlocks: number
  maxTokens: number
  maxStatements: number
  maxNodes: number
  maxPathPoints: number
  maxNesting: number
  maxStringBytes: number
  maxSingleRasterPixels: number
  maxTotalRasterBytes: number
  maxWorkerTimeMs: number
  maxRenderPixels: number
  maxCacheBytes: number
}

export interface FileViewerIllustratorFontReference {
  postScriptName: string
  family?: string
  style?: string
  subset?: boolean
}

export interface FileViewerIllustratorResourceReference {
  id: string
  kind: string
  path?: string
  uri?: string
  sha256?: string
}

export interface FileViewerIllustratorFontResolver {
  resolve(
    reference: FileViewerIllustratorFontReference,
    signal: AbortSignal
  ): Promise<ArrayBuffer | FontFace | null>
}

export interface FileViewerIllustratorResourceResolver {
  resolve(
    reference: FileViewerIllustratorResourceReference,
    signal: AbortSignal
  ): Promise<ArrayBuffer | null>
}

export interface FileViewerDesignOptions {
  /** Illustrator routing: PDF-compatible surface, native PGF scene, or safe automatic fallback. */
  illustratorMode?: FileViewerIllustratorMode
  /** Self-hosted module Worker that runs the standalone illustrator-pgf parser and renderer. */
  illustratorWorkerUrl?: string | URL
  /** Resource budgets forwarded to illustrator-pgf. Defaults to the SDK's bounded limits. */
  illustratorLimits?: Partial<FileViewerIllustratorLimits>
  /** Optional host font resolver used only by the native Illustrator session. */
  illustratorFontResolver?: FileViewerIllustratorFontResolver
  /** Optional host linked/embedded resource resolver used only by the native Illustrator session. */
  illustratorResourceResolver?: FileViewerIllustratorResourceResolver
  /** Self-hosted module Worker used for heavy Adobe document parsing and pixel synthesis. */
  workerUrl?: string | URL
  /** Self-hosted module Worker used for bounded FLA/XFL, XD, INDD/INDT, ICML/IDMS/INX, ASE, and ACO parsing. */
  containerWorkerUrl?: string | URL
  /** Self-hosted module Worker used for ABR/CSH/PAT/GRD/ASL resource parsing. */
  adobeResourceWorkerUrl?: string | URL
  /** Self-hosted module Worker that runs the bounded EPS/PostScript interpreter. */
  postscriptWorkerUrl?: string | URL
  /** Self-hosted, license-safe Stet WebAssembly binary used only inside the PostScript Worker. */
  postscriptWasmUrl?: string | URL
  /** Defaults to true. Disable only when Worker is unavailable. */
  useWorker?: boolean
  /** Maximum parser time before the Worker is terminated. Defaults to 60 seconds. */
  workerTimeoutMs?: number
  /** Base EPS/PostScript rasterization density. Defaults to 96 DPI. */
  postscriptRenderDpi?: number
  /** Maximum pages produced by one EPS/PostScript program. Defaults to 100. */
  postscriptMaxPages?: number
  /** Maximum source width or height reported by a PostScript page. Defaults to 100,000 units. */
  postscriptMaxSourceDimension?: number
  /** Maximum PostScript virtual-machine allocation. Defaults to 256 MiB. */
  postscriptMaxVmBytes?: number
  /** Maximum PostScript print working set across visible, cached, transient, and print RGBA canvases. Defaults to 128 MiB. */
  postscriptMaxPrintBytes?: number
  /** Self-hosted module Worker used by the high-fidelity IDML page renderer. */
  idmlWorkerUrl?: string | URL
  /** Self-hosted @paged-media/introspect-wasm binary used only inside the IDML Worker. */
  idmlWasmUrl?: string | URL
  /** Base rasterization density for IDML pages. Defaults to 96 DPI. */
  idmlRenderDpi?: number
  /** Maximum IDML ZIP entry count. Defaults to 20,000. */
  idmlMaxEntries?: number
  /** Maximum total expanded bytes declared by an IDML package. Defaults to 512 MiB. */
  idmlMaxExpandedBytes?: number
  /** Maximum IDML page count exposed by the renderer. Defaults to 500. */
  idmlMaxPages?: number
  /** Maximum frame count exposed by the IDML page tree. Defaults to 100,000. */
  idmlMaxFrames?: number
  /** Maximum IDML print working set across visible, cached, transient, and print RGBA canvases. Defaults to 128 MiB. */
  idmlMaxPrintBytes?: number
  /** Maximum structured result returned for ICML/IDMS/INX parsing. Defaults to 24 MiB and is hard-capped at 64 MiB. */
  indesignExchangeMaxResultBytes?: number
  /** Maximum geometry points retained for one ICML/IDMS/INX page item. Defaults to 4,096 and is hard-capped at 16,384. */
  indesignExchangeMaxPointsPerItem?: number
  /** Maximum DOM/SVG nodes materialized for one active ICML/IDMS/INX panel. Defaults to 8,000 and is hard-capped at 20,000. */
  indesignExchangeMaxDomNodesPerPanel?: number
  /** Maximum accepted Photoshop source size. Defaults to 128 MiB. */
  maxFileBytes?: number
  /** Maximum document canvas area. Defaults to 16 megapixels. */
  maxCanvasPixels?: number
  /** Maximum width or height accepted for a browser canvas. Defaults to 16,384 pixels. */
  maxCanvasDimension?: number
  /** Maximum decoded layer count. Defaults to 2,000. */
  maxLayers?: number
  /** Maximum group nesting depth. Defaults to 64. */
  maxNestingDepth?: number
  /** Maximum area decoded for one interactive layer. Defaults to 16 megapixels. */
  maxLayerPixels?: number
  /** Maximum transferred RGBA bytes for one result. Defaults to 128 MiB. */
  maxDecodedBytes?: number
  /** Maximum retained interactive layer canvas bytes. Defaults to 64 MiB. */
  maxLayerCacheBytes?: number
  /** Maximum colors, brushes, shapes, pages, or other resource records. Defaults to 4,096. */
  maxResourceItems?: number
  /** Maximum UTF-16 code units accepted for one resource name. Defaults to 4,096. */
  maxResourceNameCodeUnits?: number
  /** Maximum total pixels decoded for one resource preview collection. Defaults to 16 megapixels. */
  maxResourcePreviewPixels?: number
  /** Safety and inventory limits for XD UCF/ZIP containers and saved raster previews. */
  xd?: {
    maxFileBytes?: number
    maxEntries?: number
    maxCentralDirectoryBytes?: number
    maxEntryNameBytes?: number
    maxPathDepth?: number
    maxEntryCompressedBytes?: number
    maxEntryUncompressedBytes?: number
    maxTotalUncompressedBytes?: number
    maxCompressionRatio?: number
    maxManifestBytes?: number
    maxStructureFileBytes?: number
    maxStructureTotalBytes?: number
    maxStructureFiles?: number
    maxJsonNodes?: number
    maxJsonDepth?: number
    maxJsonStringBytes?: number
    maxPreviewCandidates?: number
    maxPreviewBytes?: number
    maxPreviewTotalBytes?: number
    maxPreviewDimension?: number
    maxPreviewPixels?: number
    maxReportedResources?: number
    maxReportedArtboards?: number
  }
  /** Safety and bounded first-frame reconstruction limits for modern ZIP/XFL-based Animate FLA files. */
  fla?: {
    maxFileBytes?: number
    maxEntries?: number
    maxCentralDirectoryBytes?: number
    maxEntryNameBytes?: number
    maxPathDepth?: number
    maxEntryCompressedBytes?: number
    maxEntryUncompressedBytes?: number
    maxTotalUncompressedBytes?: number
    maxCompressionRatio?: number
    maxXmlFileBytes?: number
    maxXmlTotalBytes?: number
    maxXmlFiles?: number
    maxXmlNodes?: number
    maxXmlDepth?: number
    maxXmlAttributes?: number
    maxXmlTextBytes?: number
    maxAttributeBytes?: number
    maxTimelines?: number
    maxLayers?: number
    maxFrames?: number
    maxSymbols?: number
    maxReportedResources?: number
    maxPreviewElements?: number
    maxPreviewPathCommands?: number
    maxPreviewSvgBytes?: number
    maxPreviewAssetBytes?: number
    maxPreviewAssetTotalBytes?: number
    maxPreviewDimension?: number
    maxPreviewPixels?: number
    maxSymbolDepth?: number
  }
  /** Safety limits for native INDD/INDT master-page, contiguous-object, XMP, and thumbnail reads. */
  inDesign?: {
    maxFileBytes?: number
    maxDatabasePages?: number
    maxContiguousObjects?: number
    maxObjectBytes?: number
    maxXmpBytes?: number
    maxPreviewCandidates?: number
    maxPreviewBytes?: number
    maxPreviewDimension?: number
    maxPreviewPixels?: number
  }
}

export type FileViewerGeoBasemapPreset =
  | 'none'
  | 'offline'
  | 'openfreemap'
  | 'openfreemap-liberty'
  | 'openfreemap-bright'
  | 'openfreemap-positron'
  | 'openfreemap-dark'
  | 'openfreemap-fiord'
  | 'osm-raster'
  | 'tianditu-vector'
  | 'tianditu-imagery'
  | 'tianditu-terrain'

export type FileViewerTiandituMapStyle = 'vector' | 'imagery' | 'terrain'

export interface FileViewerGeoBasemapOptions {
  /**
   * `raster` uses XYZ/TMS image tiles. `vector-style` uses a MapLibre style
   * object or URL, which is the best path for OpenFreeMap/OpenMapTiles stacks.
   * `tianditu` builds the official base and annotation raster layers from the
   * caller-provided Tianditu token.
   */
  type?: 'raster' | 'vector-style' | 'tianditu'
  /**
   * Raster XYZ/TMS tile template, for example `/tiles/{z}/{x}/{y}.png`.
   */
  tileUrl?: string | string[]
  /**
   * MapLibre style JSON URL. Can point to a public source, an intranet mirror,
   * or an offline static file distributed with the viewer.
   */
  styleUrl?: string
  /**
   * Inline MapLibre style object for fully offline deployments.
   */
  style?: Record<string, unknown>
  /**
   * Human-readable label shown in the geo preview details panel.
   */
  label?: string
  attribution?: string
  tileSize?: number
  minZoom?: number
  maxZoom?: number
  scheme?: 'xyz' | 'tms'
  rasterOpacity?: number
  /** Tianditu API token. Required when `type` is `tianditu`. */
  token?: string
  /** Tianditu map family. Defaults to `vector`. */
  mapStyle?: FileViewerTiandituMapStyle
  /** Include the matching Tianditu annotation layer. Defaults to true. */
  labels?: boolean
}

export interface FileViewerGeoOptions {
  /**
   * Source coordinate reference system. GeoJSON normally uses WGS84, but many
   * business exports carry Web Mercator, GCJ-02, BD-09, or legacy CRS metadata.
   *
   * Accepts values such as `EPSG:4326`, `EPSG:3857`, `CRS:84`, `GCJ02`,
   * `BD09`, or a proj4 definition string.
   */
  projection?: string
  /**
   * Convenience raster tile URL. The renderer stays offline by default; setting
   * this property opts into a raster basemap without requiring a full MapLibre
   * style. Use `basemap` when you need a named preset or vector style URL.
   */
  tileUrl?: string | string[]
  /**
   * Basemap configuration. Defaults to an offline empty MapLibre style.
   *
   * Built-in presets are opt-in: `openfreemap-liberty` uses the public
   * OpenFreeMap MapLibre style, and `osm-raster` uses the public OSM raster
   * tiles for light usage or demos. Production systems should prefer a
   * self-hosted or intranet style/tile URL.
   */
  basemap?: false | FileViewerGeoBasemapPreset | FileViewerGeoBasemapOptions
  /**
   * Tianditu API token used by the `tianditu-*` presets. The viewer never
   * supplies or persists a token; obtain one for the deployment's own domain.
   */
  tiandituToken?: string
  /**
   * Defaults to true. When no CRS is declared and coordinates exceed longitude
   * or latitude ranges, the geo renderer treats Web Mercator-sized values as
   * EPSG:3857 before rendering.
   */
  inferProjection?: boolean
  /**
   * Defaults to true. Disable only for environments without reliable WebGL,
   * where the SVG fallback is preferred.
   */
  preferMapEngine?: boolean
  /**
   * Padding in CSS pixels when fitting the dataset bounds in the map viewport.
   */
  fitPadding?: number
}

export interface FileViewerDrawingOptions {
  /**
   * Self-hosted diagrams.net viewer script.
   *
   * The default points to the optional viewer asset copied under
   * `vendor/drawio/viewer-static.min.js`. It is only requested when
   * `preferOfficial` is explicitly enabled and never reaches public
   * diagrams.net hosts.
   */
  viewerScriptUrl?: string
  /**
   * Defaults to false so untrusted diagrams use the inert built-in SVG path.
   * Set to true only to opt into the separately delivered diagrams.net viewer
   * runtime. It runs in a no-same-origin iframe with a restrictive CSP.
   */
  preferOfficial?: boolean
  /**
   * PlantUML SVG endpoint. When omitted, the renderer stays fully offline and
   * shows an SVG source preview. When provided, the renderer appends the
   * encoded PlantUML payload to this base URL. Self-host this endpoint for
   * intranet preview.
   *
   * Example: `/plantuml/svg/`.
   */
  plantumlServerUrl?: string
  /**
   * Request timeout for server-rendered PlantUML SVG.
   */
  plantumlTimeoutMs?: number
}

export type FileViewerCadRenderer = 'auto' | 'webgl' | 'canvas2d'
export type FileViewerCadDwfLineWeightMode = 'adaptive' | 'physical' | 'hairline'
export type FileViewerCadColorMode = 'source' | 'monochrome'
export type FileViewerCadFitMode = 'best' | 'native'

export interface FileViewerCadOptions {
  wasmPath?: string
  workerUrl?: string | URL
  dwfWasmUrl?: string
  dxfEncoding?: string
  useWorker?: boolean
  workerTimeoutMs?: number
  renderer?: FileViewerCadRenderer
  /** Initial CAD color policy. `monochrome` applies one plot color without mutating source data. */
  colorMode?: FileViewerCadColorMode
  /** CSS color used by monochrome mode. Defaults to black (#000000). */
  monochromeColor?: string
  /** Shows the CAD toolbar color-mode toggle. Defaults to true. */
  showColorModeToggle?: boolean
  /** Show native PNG/JPEG snapshot downloads. Download/export permissions still apply. */
  showImageExport?: boolean
  preferDwgWasm?: boolean
  includePaperSpace?: boolean
  maxInsertDepth?: number
  keepRaw?: boolean
  preloadDwg?: boolean
  /**
   * `best` fits the first view to visible drawing geometry and ignores common
   * CAD outliers such as paper-space frames or far-away markers. `native`
   * preserves the raw bounds reported by the underlying CAD renderer.
   */
  fitMode?: FileViewerCadFitMode
  /**
   * Fraction of the CAD viewport used by fit-to-view. Defaults to 0.92.
   */
  fitPadding?: number
  dwfPreferWebgl?: boolean
  dwfPreferWasm?: boolean
  /** Explicit DWF background override; otherwise follows the current color mode. */
  dwfBackground?: string
  dwfMaxDevicePixelRatio?: number
  dwfMaxCanvasPixels?: number
  dwfMaxGpuCacheBytes?: number
  dwfMaxCachedScenes?: number
  dwfLineWeightMode?: FileViewerCadDwfLineWeightMode
  dwfMinStrokeCssPx?: number
  dwfMaxOverviewStrokeCssPx?: number
  dwfMinTextCssPx?: number
  dwfMinFilledAreaCssPx?: number
  /** Default background is dark for source colors and white for monochrome. Explicit colors are retained. */
  canvasOptions?: Record<string, unknown>
}

export type FileViewerRendererMode = 'extend' | 'replace'
export type FileViewerBuiltinRendererPreset = 'all' | 'lite' | 'none'
export type FileViewerRendererPresetName = 'all' | 'lite' | 'standard' | 'office' | 'engineering'

export interface FileViewerAutoRendererOptions {
  /**
   * Uses renderer presets registered by build tooling or preset side-effect imports.
   *
   * Defaults to true in `extend` mode and false in `replace` mode so applications
   * can keep a strict hand-picked renderer registry when needed.
   */
  enabled?: boolean
}

export interface FileViewerSearchOptions {
  enabled?: boolean
  caseSensitive?: boolean
  wholeWord?: boolean
  maxMatches?: number
  debounce?: number
  className?: string
  activeClassName?: string
}

export interface FileViewerAiOptions {
  enabled?: boolean
  collectText?: boolean
  maxTextLength?: number
  chunkSize?: number
  chunkOverlap?: number
}

export interface FileViewerTextOptions {
  /** Initial HTML/HTM view. Preview is static, sandboxed, and offline; defaults to preview. */
  htmlView?: 'preview' | 'source'
  /**
   * Source encoding. Defaults to `auto`: BOM and UTF-16 structure first,
   * then strict UTF-8, then `fallbackEncoding`. Explicit single-byte labels
   * decode legacy Latin, Cyrillic, and Central European files. Browsers
   * decode the `iso-8859-1` label with the windows-1252 table, as the
   * WHATWG Encoding Standard requires.
   */
  encoding?:
    | 'auto'
    | 'utf-8'
    | 'utf-16le'
    | 'utf-16be'
    | 'gbk'
    | 'gb18030'
    | 'iso-8859-1'
    | 'iso-8859-2'
    | 'iso-8859-15'
    | 'windows-1250'
    | 'windows-1251'
    | 'windows-1252'
  /**
   * Encoding used by `auto` for bytes that are not valid UTF-8 and carry no
   * BOM or UTF-16 structure. Defaults to `gb18030`, which preserves the
   * historical behavior for GBK files. Set `windows-1252` for Western
   * European sources or `windows-1251` for Cyrillic sources. Legacy byte
   * sequences can also be valid UTF-8 or GB18030; use an explicit `encoding`
   * when the source is known. Ignored when `encoding` is explicit.
   */
  fallbackEncoding?:
    | 'utf-8'
    | 'gbk'
    | 'gb18030'
    | 'iso-8859-1'
    | 'iso-8859-2'
    | 'iso-8859-15'
    | 'windows-1250'
    | 'windows-1251'
    | 'windows-1252'
  /**
   * Shows the renderer-local source metadata toolbar (file type, indexing
   * status, and line count). Defaults to true. This does not control the
   * viewer-level operation toolbar.
   */
  toolbar?: boolean
  /**
   * Shows a non-selectable, screen-reader-hidden line-number gutter for code and text.
   * Defaults to false for regular files. The virtual large-text view keeps its
   * historical visible gutter when this option is omitted; pass false to hide it.
   */
  lineNumbers?: boolean
  /**
   * Visually wraps long logical lines without inserting source newlines. Defaults to false.
   * Wrapped continuation rows remain associated with their original line number.
   */
  wrapLongLines?: boolean
  /**
   * Formats supported structured text with lazily loaded Prettier plugins for display only.
   * Defaults to false; malformed, unsupported, or oversized inputs keep their original source.
   */
  prettyPrint?: boolean
  /**
   * Maximum decoded UTF-8 source bytes eligible for Prettier. Defaults to the effective
   * `virtualizeAboveBytes` value, or 512 KiB when that option is omitted.
   */
  prettyPrintMaxBytes?: number
  /** Switches text and code to bounded virtual rendering above this byte size. Defaults to 512 KiB. */
  virtualizeAboveBytes?: number
  /**
   * Opts Markdown into source-mode virtual rendering above this byte size.
   * Markdown stays in its rendered reading view by default; set this only when
   * an application prefers bounded source inspection for exceptionally large files.
   */
  markdownVirtualizeAboveBytes?: number
  /** Highlights fenced Markdown code with a declared language. Defaults to true; bounded to 512 KiB of code per document. */
  markdownHighlight?: boolean
  /** Maximum source bytes mounted for one very long logical line at a time. Defaults to 16 KiB. */
  maxRenderedLineBytes?: number
  /** Extra logical lines mounted above and below the visible viewport. Defaults to 12. */
  virtualOverscanLines?: number
}

export type FileViewerUiDensity = 'comfortable' | 'compact'

export interface FileViewerUiOptions {
  /**
   * Controls spacing density for viewer chrome such as toolbars, headers,
   * archive lists, badges, search inputs, and compact action clusters.
   */
  density?: FileViewerUiDensity
  /**
   * Overrides the workspace behind rendered pages, slides, and other preview
   * content. Pass any valid CSS background value (for example `transparent`)
   * to let the host application provide an immersive surface. Omit this value,
   * or pass `auto`, to keep each renderer's light/dark default.
   *
   * This does not change document pages, slide canvases, spreadsheet cells, or
   * other file-authored backgrounds.
   */
  surfaceBackground?: string
}

export interface FileViewerDiagnostic {
  code: string
  level: 'info' | 'warning' | 'error'
  message: string
  detail?: Readonly<Record<string, unknown>>
}

export interface FileViewerOptions {
  /** Opt-in signature renderer configuration, read when a document is rendered.
   * updateOptions does not update an already mounted signature panel. */
  signature?: FileViewerSignatureOptions
  theme?: FileViewerThemeMode
  /** Ctrl/Meta wheel and two-finger document zoom. Enabled when a zoom provider
   * is available; ordinary scrolling and interactive controls stay native.
   * Use false or disable individual gestures for a host that owns them.
   */
  zoomGestures?: boolean | { wheel?: boolean; pinch?: boolean }
  /**
   * Controls how aggressively the viewer protects its DOM and CSS from the
   * host page. Standard component packages resolve `auto` to Shadow DOM so
   * host resets cannot break the toolbar or rendered content. Use `none`
   * explicitly only for legacy integrations that require deep class overrides.
   */
  styleIsolation?: FileViewerStyleIsolation
  /**
   * Viewer UI language. `auto` follows the browser language and resolves the
   * seven bundled locales from FILE_VIEWER_LOCALE_METADATA before falling
   * back to `en-US`.
   */
  locale?: FileViewerLocale
  /**
   * Optional custom copy for built-in viewer UI. Use `i18n.messages` when you
   * also want to keep locale and messages grouped together.
   */
  messages?: FileViewerMessages
  i18n?: FileViewerI18nOptions
  /**
   * Controls how explicit renderer packages or presets are merged into this
   * viewer instance.
   *
   * `extend` mode keeps the configured built-in baseline and appends explicit
   * renderers. `replace` mode starts from an empty registry, so `preset` or
   * `renderers` fully define the active capability set.
   */
  rendererMode?: FileViewerRendererMode
  /**
   * Advanced baseline switch for built-in browser renderers.
   *
   * Most applications can ignore this option and use `preset` / `renderers`
   * with `rendererMode:'replace'`. Keep it for compatibility or very strict
   * registry control: `all` preserves the historical full baseline, `lite`
   * keeps only low-cost web-native previewers, and `none` starts from an empty
   * built-in baseline while still allowing explicit renderer assembly.
   */
  builtinRenderers?: FileViewerBuiltinRendererPreset
  /**
   * Enables renderer presets that were auto-registered by `@file-viewer/vite-plugin`
   * or by explicitly importing a preset package. Set to false when a product wants
   * total manual control through `renderers`.
   */
  autoRenderers?: boolean | FileViewerAutoRendererOptions
  /**
   * Product-shaped renderer preset or preset list installed into this viewer
   * instance.
   *
   * This is the bundler-neutral path for Webpack, Rspack, Rollup, Umi,
   * legacy script builds, and any environment that should not depend on the
   * Vite virtual module. Import one or more preset packages and pass them here:
   *
   * `const officePreset = await import(theInstalledOfficePresetPackage)`
   * `options: { preset: officePreset.default }`
   * `options: { preset: [officePreset.default, engineeringPreset.default] }`
   *
   * The string form (`'office'`, `'all'`, etc.) selects a preset that has
   * already been registered by a preset side-effect import or by
   * `@file-viewer/vite-plugin`.
   */
  preset?: FileViewerRendererPresetInput
  /**
   * @deprecated Use `preset: [officePreset, engineeringPreset]` instead. This
   * alias is kept only for compatibility with early 2.x integration drafts.
   */
  presets?: FileViewerRendererPresetInput
  renderers?: FileViewerRendererPluginInput
  watermark?: boolean | FileViewerWatermarkOptions
  ui?: FileViewerUiOptions
  toolbar?: boolean | FileViewerToolbarOptions
  search?: boolean | FileViewerSearchOptions
  ai?: boolean | FileViewerAiOptions
  text?: FileViewerTextOptions
  /**
   * Explicit content fitting strategy. When omitted, each renderer keeps its
   * historical first-screen behavior for backward compatibility.
   */
  fit?: FileViewerFitMode | FileViewerFitOptions
  /**
   * Initial renderer view position used after the document becomes ready.
   *
   * Renderers apply the fields they understand. All standard renderer paths
   * expose at least renderer / zoom / scroll snapshots through the generic
   * provider; high-interaction renderers such as PDF, XMind, Geo, 3D, and CAD
   * add page, navigation, canvas, map, camera, or native view details.
   */
  initialViewState?: FileViewerViewState
  archive?: FileViewerArchiveOptions
  chm?: FileViewerChmOptions
  pdf?: FileViewerPdfOptions
  epub?: FileViewerEpubOptions
  docx?: FileViewerDocxOptions
  presentation?: FileViewerPresentationOptions
  spreadsheet?: FileViewerSpreadsheetOptions
  /** Image renderer controls; also applies to multipage TIFF previews. */
  image?: {
    /** Enable mouse drag panning of overflowing images. Defaults to false; touch scrolling and lightbox clicks are preserved. */
    handTool?: boolean
    /**
     * Show rotation controls and allow view-state rotation. Defaults to true.
     * Set false for compact previews. Decoder/EXIF orientation is unchanged.
     */
    rotation?: boolean
  }
  iwork?: FileViewerIworkOptions
  wordPerfect?: FileViewerWordPerfectOptions
  hangul?: FileViewerHangulOptions
  /** Receives non-fatal routing, fallback, and capability diagnostics. */
  onDiagnostic?: (diagnostic: FileViewerDiagnostic) => void
  typst?: FileViewerTypstOptions
  geo?: FileViewerGeoOptions
  data?: FileViewerDataOptions
  binary?: FileViewerBinaryInspectorOptions
  /** Configuration for the explicitly installed XML profile renderer. */
  xml?: FileViewerXmlOptions
  design?: FileViewerDesignOptions
  drawing?: FileViewerDrawingOptions
  cad?: FileViewerCadOptions
  model?: FileViewerModelOptions
  hooks?: FileViewerLifecycleHooks
  beforeOperation?: FileViewerBeforeOperation
}

export interface FileViewerLifecycleContext {
  phase: FileViewerLifecyclePhase
  type: string
  filename: string
  source: FileViewerSourceKind
  url?: string
  file?: File
  size?: number
  version: number
  timestamp: number
  duration?: number
  reason?: 'replace' | 'reset' | 'component-unmount'
}

export interface FileViewerLifecycleHooks {
  onLoadStart?: (context: FileViewerLifecycleContext) => void | Promise<void>
  onLoadComplete?: (context: FileViewerLifecycleContext) => void | Promise<void>
  onUnloadStart?: (context: FileViewerLifecycleContext) => void | Promise<void>
  onUnloadComplete?: (context: FileViewerLifecycleContext) => void | Promise<void>
}

export interface FileViewerOperationContext extends Omit<FileViewerLifecycleContext, 'phase'> {
  operation: FileViewerOperationType
  label: string
}

export type FileViewerBeforeOperation = (
  context: FileViewerOperationContext
) => boolean | void | Promise<boolean | void>

export interface FileViewerOperationAvailability {
  download: boolean
  print: boolean
  exportHtml: boolean
  zoom: boolean
  zoomIn: boolean
  zoomOut: boolean
  zoomReset: boolean
}

export interface FileViewerStateTheme {
  accent: string
  badge: string
  hint: string
  label: string
  soft: string
}

export interface FileViewerStateDescriptor {
  state: FileViewerRenderStateKind
  extension: string
  title: string
  message: string
  description?: string
  theme: FileViewerStateTheme
  recoverable: boolean
}

export interface FileViewerZoomState {
  scale: number
  label: string
  canZoomIn: boolean
  canZoomOut: boolean
  canReset: boolean
  minScale?: number
  maxScale?: number
}

export interface FileViewerFitRequest extends Required<
  Pick<FileViewerFitOptions, 'mode' | 'resize' | 'padding'>
> {
  minScale?: number
  maxScale?: number
  source: FileViewerViewStateChangeSource
  reason: 'initial' | 'resize' | 'api' | 'retry'
  viewportWidth: number
  viewportHeight: number
  container?: HTMLElement | null
}

export interface FileViewerFitResult {
  applied: boolean
  mode: FileViewerFitMode
  resize: FileViewerFitResize
  scale?: number
  source?: FileViewerViewStateChangeSource
  reason?: string
  provider?: 'view-state' | 'zoom' | 'none' | (string & {})
  state?: FileViewerViewState
}

export interface FileViewerZoomProvider {
  zoomIn: () => FileViewerZoomState | Promise<FileViewerZoomState>
  zoomOut: () => FileViewerZoomState | Promise<FileViewerZoomState>
  resetZoom: () => FileViewerZoomState | Promise<FileViewerZoomState>
  setZoom?: (scale: number) => FileViewerZoomState | Promise<FileViewerZoomState>
  fit?: (request: FileViewerFitRequest) => FileViewerFitResult | Promise<FileViewerFitResult>
  getState: () => FileViewerZoomState
  subscribe?: (listener: () => void) => () => void
}

export interface FileViewerViewScrollState {
  top: number
  left: number
  width: number
  height: number
  clientWidth: number
  clientHeight: number
  topRatio: number
  leftRatio: number
}

export interface FileViewerNavigationState {
  visible?: boolean
  mode?: string
}

/** Zero-based workbook sheet id and inclusive cell bounds. */
export interface FileViewerSpreadsheetRange {
  sheetId: number;
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}
export type FileViewerSpreadsheetNavigationStatus =
  'idle' | 'pending' | 'applied' | 'rejected' | 'cancelled' | 'failed' | 'disposed';

export interface FileViewerViewState {
  /** Coordinate navigation for spreadsheets; does not edit or select cell contents. */
  spreadsheet?: {
    /** Active workbook sheet id, retained for restoring views without a range. */
    sheetId?: number;
    range?: FileViewerSpreadsheetRange;
    status?: FileViewerSpreadsheetNavigationStatus;
  };
  renderer?: string
  page?: number
  pageCount?: number
  scale?: number
  zoom?: FileViewerZoomState
  rotation?: number
  scroll?: Partial<FileViewerViewScrollState>
  navigation?: FileViewerNavigationState
  extra?: Record<string, unknown>
}

export type FileViewerViewStateChangeSource = 'initial' | 'api' | 'user' | 'viewer' | (string & {})

export type FileViewerViewStateChangeAction =
  | 'init'
  | 'restore'
  | 'page-change'
  | 'page-click'
  | 'page-step'
  | 'outline-click'
  | 'zoom-change'
  | 'zoom-in'
  | 'zoom-out'
  | 'zoom-reset'
  | 'fit'
  | 'rotation-change'
  | 'rotate-left'
  | 'rotate-right'
  | 'scroll'
  | 'navigation-toggle'
  | 'navigation-mode-change'
  | (string & {})

export interface FileViewerViewStateChange {
  state: FileViewerViewState
  action: FileViewerViewStateChangeAction
  source: FileViewerViewStateChangeSource
  timestamp: number
}

export interface FileViewerApplyViewStateOptions {
  notify?: boolean
  action?: FileViewerViewStateChangeAction
  source?: FileViewerViewStateChangeSource
}

export interface FileViewerViewStateProvider {
  getState: () => FileViewerViewState
  applyState?: (
    state: FileViewerViewState,
    options?: FileViewerApplyViewStateOptions
  ) => FileViewerViewState | Promise<FileViewerViewState>
  fit?: (request: FileViewerFitRequest) => FileViewerFitResult | Promise<FileViewerFitResult>
  subscribe?: (listener: (change: FileViewerViewStateChange) => void) => () => void
}

export interface FileViewerSearchMatch {
  id: string
  index: number
  text: string
  anchor: FileViewerDocumentAnchor | null
  line?: number
  page?: number
}

export interface FileViewerSearchState {
  query: string
  total: number
  currentIndex: number
  current: FileViewerSearchMatch | null
  matches: FileViewerSearchMatch[]
}

export interface FileViewerSearchProvider {
  search: (
    query: string,
    options?: FileViewerSearchOptions
  ) => FileViewerSearchState | Promise<FileViewerSearchState>
  next?: () => FileViewerSearchState | Promise<FileViewerSearchState>
  previous?: () => FileViewerSearchState | Promise<FileViewerSearchState>
  clear?: () => FileViewerSearchState | Promise<FileViewerSearchState>
  getState?: () => FileViewerSearchState
}

export interface FileViewerDocumentAnchor {
  id: string
  index: number
  line: number
  type: 'page' | 'line' | 'block'
  label: string
  text: string
  page?: number
  top: number
  left: number
  width: number
  height: number
}

export interface FileViewerDocumentChunk {
  id: string
  text: string
  anchor: FileViewerDocumentAnchor
  startLine: number
  endLine: number
}

export interface FileViewerComponentProps {
  file?: FileViewerFileRef
  url?: string
  name?: string
  filename?: string
  type?: string
  size?: number
  options?: FileViewerOptions
}

export interface FileViewerComponentEventMap {
  'load-start': FileViewerLifecycleContext
  'load-complete': FileViewerLifecycleContext
  'unload-start': FileViewerLifecycleContext
  'unload-complete': FileViewerLifecycleContext
  'operation-before': FileViewerOperationContext
  'operation-cancel': FileViewerOperationContext
  'operation-availability-change': FileViewerOperationAvailability
  'search-change': FileViewerSearchState
  'location-change': FileViewerDocumentAnchor | null
  'zoom-change': FileViewerZoomState
  'view-state-change': FileViewerViewStateChange
  'fit-change': FileViewerFitResult
  'theme-change': FileViewerResolvedThemeMode
}

export type FileViewerEventType = keyof FileViewerComponentEventMap

export type FileViewerEvent = {
  [EventType in FileViewerEventType]: {
    type: EventType
    payload: FileViewerComponentEventMap[EventType]
  }
}[FileViewerEventType]

export type FileViewerEventHandler = (event: FileViewerEvent) => void

export interface FileViewerComponentEmits {
  (event: 'load-start', context: FileViewerComponentEventMap['load-start']): void
  (event: 'load-complete', context: FileViewerComponentEventMap['load-complete']): void
  (event: 'unload-start', context: FileViewerComponentEventMap['unload-start']): void
  (event: 'unload-complete', context: FileViewerComponentEventMap['unload-complete']): void
  (event: 'operation-before', context: FileViewerComponentEventMap['operation-before']): void
  (event: 'operation-cancel', context: FileViewerComponentEventMap['operation-cancel']): void
  (
    event: 'operation-availability-change',
    availability: FileViewerComponentEventMap['operation-availability-change']
  ): void
  (event: 'search-change', state: FileViewerComponentEventMap['search-change']): void
  (event: 'location-change', anchor: FileViewerComponentEventMap['location-change']): void
  (event: 'zoom-change', state: FileViewerComponentEventMap['zoom-change']): void
  (event: 'view-state-change', change: FileViewerComponentEventMap['view-state-change']): void
  (event: 'fit-change', result: FileViewerComponentEventMap['fit-change']): void
  (event: 'theme-change', theme: FileViewerComponentEventMap['theme-change']): void
}

export interface FileViewerPublicApi {
  destroy(): void
  downloadOriginalFile(): Promise<void>
  printRenderedHtml(options?: FileViewerPrintOptions): Promise<void>
  printWithMask(options?: FileViewerPrintOptions): Promise<void>
  exportRenderedHtml(): Promise<void>
  zoomIn(): Promise<FileViewerZoomState>
  zoomOut(): Promise<FileViewerZoomState>
  resetZoom(): Promise<FileViewerZoomState>
  fitToView(fit?: FileViewerFitMode | FileViewerFitOptions): Promise<FileViewerFitResult>
  getZoomState(): FileViewerZoomState
  getViewState(): FileViewerViewState | null
  applyViewState(
    state: FileViewerViewState,
    options?: FileViewerApplyViewStateOptions
  ): Promise<FileViewerViewState | null>
  getOperationAvailability(): FileViewerOperationAvailability
  getScrollContainer(): HTMLElement | null
  searchDocument(query: string): Promise<FileViewerSearchState>
  clearDocumentSearch(): Promise<FileViewerSearchState>
  nextSearchResult(): Promise<FileViewerSearchState>
  previousSearchResult(): Promise<FileViewerSearchState>
  getSearchState(): FileViewerSearchState
  collectDocumentAnchors(): Promise<FileViewerDocumentAnchor[]>
  scrollToAnchor(anchor: FileViewerDocumentAnchor | string): Promise<boolean>
  scrollToLine(line: number): Promise<boolean>
  getDocumentTextChunks(): FileViewerDocumentChunk[]
}

export interface FileViewerDownloadOptions {
  filename?: string
}

export interface FileViewerExportHtmlOptions {
  download?: boolean
  filename?: string
  title?: string
  watermarkInlineStyle?: string
}

/** Normalized print-mask rectangle in percent of the rendered content box. */
export interface FileViewerPrintMaskRegion {
  left: number
  top: number
  width: number
  height: number
  /** Zero-based rendered page index. Omitted regions retain legacy whole-document coordinates. */
  pageIndex?: number
}

/** Page-aware image placed above rendered content for printing, such as a seal or signature. */
export interface FileViewerPrintStamp extends FileViewerPrintMaskRegion {
  /** Image URL. Uploaded stamps are converted to a local data URL by the designer. */
  src: string
  /** Image opacity from 0 to 1. Defaults to 1. */
  opacity?: number
  /** Clockwise rotation in degrees. Defaults to 0. */
  rotate?: number
  alt?: string
}

export interface FileViewerPrintMaskOptions {
  /** Solid black cover blocks, matching common OFD/business redaction UX. */
  regions?: FileViewerPrintMaskRegion[]
  /** Image overlays, including locally uploaded seals and signatures. */
  stamps?: FileViewerPrintStamp[]
  /** Fill color for print masks. Defaults to opaque black. */
  color?: string
}

export interface FileViewerPrintOptions {
  autoPrint?: boolean
  openWindow?: () => Window | null
  printWindow?: Window | null
  title?: string
  watermarkInlineStyle?: string
  /** Optional print-time cover masks applied above content and below watermark. */
  mask?: FileViewerPrintMaskOptions | null
}

export interface FileViewerSource {
  url?: string
  file?: File | Blob
  buffer?: ArrayBuffer
  filename?: string
  type?: string
  size?: number
}

export interface NormalizedFileViewerSource {
  kind: FileViewerSourceKind
  filename: string
  extension: string
  url?: string
  file?: File | Blob
  buffer?: ArrayBuffer
  size?: number
}

export interface RenderSurface {
  host?: HTMLElement
  container: HTMLElement
  shadowRoot?: ShadowRoot
  styleIsolation?: Exclude<FileViewerStyleIsolation, 'auto'>
}

export interface RendererCapability {
  download?: boolean
  print?: boolean | 'adapter'
  exportHtml?: boolean | 'adapter'
  zoom?: boolean | 'provider'
  search?: boolean | 'provider'
}

export type FileViewerFormatSupportLevel = 'high-fidelity' | 'structured' | 'basic' | 'experimental'
export type FileViewerFormatStatus = 'stable' | 'experimental'

export interface RendererSourceTypeProbeInput {
  filename: string
  extension: string
  url?: string
  file?: File | Blob
  buffer?: ArrayBuffer
  mimeType?: string
  signal?: AbortSignal
}

export type RendererSourceTypeProbe = (
  input: RendererSourceTypeProbeInput
) => string | false | null | undefined | Promise<string | false | null | undefined>

export interface RendererDefinition {
  id: string
  label: string
  category: FileViewerRendererCategory
  extensions: readonly string[]
  /** Optional compound filename claims such as tileset.json or *.copc.laz. */
  filenamePatterns?: readonly string[]
  /** Prefer passing the original URL to the renderer instead of eagerly downloading it. */
  sourceAccess?: 'buffer' | 'stream-preferred'
  /**
   * Optional bounded content probe. Return the specialist type to route the
   * source through this renderer, or false when the existing extension owner
   * must remain unchanged.
   */
  resolveSourceType?: RendererSourceTypeProbe
  async?: boolean
  /** Product-level fidelity contract generated from ecosystem/format-catalog.json. */
  supportLevel?: FileViewerFormatSupportLevel
  /** Experimental formats are routable but are excluded from stable support counts. */
  status?: FileViewerFormatStatus
  /** Owning on-demand renderer package. */
  packageName?: string
  /** Presets that assemble this renderer. */
  presets?: readonly FileViewerRendererPresetName[]
  /** Existing renderer whose fallback extensions this specialist replaces when installed. */
  enhancesRendererId?: string
  /** Extensions transferred from enhancesRendererId to this specialist when installed. */
  enhancesExtensions?: readonly string[]
  containerVersions?: readonly string[]
  knownLimits?: readonly string[]
  capabilities?: RendererCapability
  load?: RendererLoader
}

export type RendererPlugin = RendererDefinition

export type ViewerLifecycleContext = FileViewerLifecycleContext

export type ViewerOperationContext = FileViewerOperationContext

export type ViewerCapabilityState = FileViewerOperationAvailability

export interface RendererLoadContext {
  source: NormalizedFileViewerSource
  surface: RenderSurface
  options: FileViewerOptions
  signal?: AbortSignal
  registerExportAdapter?: (adapter: FileRenderExportAdapter | null) => void
  registerThumbnailAdapter?: (adapter: FileRenderThumbnailAdapter | null) => void
  renderContext?: FileRenderContext
}

export interface RendererSession {
  destroy?: () => void | Promise<void>
  getAvailability?: () => Partial<FileViewerOperationAvailability>
}

export type RendererLoader = (
  context: RendererLoadContext
) => RendererSession | Promise<RendererSession>

export interface RendererRegistry {
  register(definition: RendererDefinition): void
  unregister(id: string): boolean
  getById(id: string): RendererDefinition | undefined
  getByExtension(extension: string): RendererDefinition | undefined
  hasExtension(extension: string): boolean
  list(): RendererDefinition[]
  listExtensions(): string[]
}

export type FileViewerRendererPluginAssetKind =
  'worker' | 'wasm' | 'script' | 'style' | 'font' | 'vendor' | 'data'

export interface FileViewerRendererPluginAssetEntry {
  id: string
  kind: FileViewerRendererPluginAssetKind
  source: string
  optional?: boolean
}

export interface FileViewerRendererPluginAssetManifest {
  packageName: string
  rendererId: string
  assets: readonly FileViewerRendererPluginAssetEntry[]
}

export interface FileViewerRendererHandlerRegistration<Handler = FileRenderHandler> {
  rendererId: string
  handler: Handler
}

export interface FileViewerRendererInstallContext<Handler = FileRenderHandler> {
  registry: RendererRegistry
  registerHandler?: (registration: FileViewerRendererHandlerRegistration<Handler>) => void
}

export interface FileViewerRendererPlugin<Handler = FileRenderHandler> {
  id: string
  label?: string
  definitions?: readonly RendererDefinition[]
  handlers?: readonly FileViewerRendererHandlerRegistration<Handler>[]
  assets?: readonly FileViewerRendererPluginAssetManifest[]
  install?: (context: FileViewerRendererInstallContext<Handler>) => void | Promise<void>
}

export interface FileViewerRendererPreset<Handler = FileRenderHandler> {
  id: string
  label?: string
  renderers: readonly FileViewerRendererPlugin<Handler>[]
}

export type FileViewerRendererPluginInput<Handler = FileRenderHandler> =
  | FileViewerRendererPlugin<Handler>
  | FileViewerRendererPreset<Handler>
  | readonly FileViewerRendererPluginInput<Handler>[]

export type FileViewerRendererPresetInput<Handler = FileRenderHandler> =
  | FileViewerRendererPresetName
  | FileViewerRendererPluginInput<Handler>
  | readonly FileViewerRendererPresetInput<Handler>[]

export interface FileViewerLoadOptions {
  signal?: AbortSignal
}

export interface FileViewerInstance {
  readonly container: HTMLElement
  /** Installs configured renderer plugins without loading a document. */
  prepare?(): Promise<void>
  load(source: FileViewerSource, options?: FileViewerLoadOptions): Promise<RendererSession | null>
  unload?(reason?: FileViewerLifecycleContext['reason']): Promise<void>
  destroy(reason?: FileViewerLifecycleContext['reason']): Promise<void>
  updateOptions(options: Partial<FileViewerOptions>): void
  getCapabilities(extension?: string): FileViewerOperationAvailability
  getRenderer(extension?: string): RendererDefinition | undefined
  getSource(): NormalizedFileViewerSource | null
  registerExportAdapter(adapter: FileRenderExportAdapter | null): void
  getExportAdapter(): FileRenderExportAdapter | null
  registerThumbnailAdapter?(adapter: FileRenderThumbnailAdapter | null): void
  getThumbnailAdapter?(): FileRenderThumbnailAdapter | null
  download(options?: FileViewerDownloadOptions): Promise<void>
  exportHtml(options?: FileViewerExportHtmlOptions): Promise<string>
  print(options?: FileViewerPrintOptions): Promise<void>
  /** Open the async print-mask designer, then print with the chosen covers. */
  printWithMask(options?: FileViewerPrintOptions): Promise<void>
  zoomIn(): Promise<FileViewerZoomState>
  zoomOut(): Promise<FileViewerZoomState>
  resetZoom(): Promise<FileViewerZoomState>
  fitToView(fit?: FileViewerFitMode | FileViewerFitOptions): Promise<FileViewerFitResult>
  getZoomState(): FileViewerZoomState
  getViewState(): FileViewerViewState | null
  applyViewState(
    state: FileViewerViewState,
    options?: FileViewerApplyViewStateOptions
  ): Promise<FileViewerViewState | null>
  search(query: string): Promise<FileViewerSearchState>
  nextSearchResult(): Promise<FileViewerSearchState>
  previousSearchResult(): Promise<FileViewerSearchState>
  clearSearch(): Promise<FileViewerSearchState>
  getSearchState(): FileViewerSearchState
  collectDocumentAnchors(): Promise<FileViewerDocumentAnchor[]>
  getCurrentDocumentAnchor(): FileViewerDocumentAnchor | null
  scrollToDocumentAnchor(
    anchor: FileViewerDocumentAnchor | string | number | null | undefined
  ): boolean
  scrollToLine(line: number): Promise<boolean>
  getDocumentTextChunks(options?: boolean | FileViewerAiOptions): FileViewerDocumentChunk[]
}
